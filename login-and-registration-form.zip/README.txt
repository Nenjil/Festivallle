A Pen created at CodePen.io. You can find this one at https://codepen.io/GrandvincentMarion/pen/epEPjp.

 Login and registration form. Inpired by Paul Flavius Nechita on dribbble : https://dribbble.com/shots/2125879-Day-001-Login-Form/attachments/387086. Thanks to him !